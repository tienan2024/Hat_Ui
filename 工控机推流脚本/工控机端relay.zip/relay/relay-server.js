/**
 * 传感器中继服务 - 运行在工控机上
 * 功能：串口(MCU) <-> TCP(PC) 双向透传
 *
 * 数据流：
 *   MCU --串口--> 工控机 --TCP--> PC (传感器数据 $DATA、应答 $ACK)
 *   PC  --TCP-->  工控机 --串口--> MCU (报警指令 $ALARM、$NORMAL)
 */

import { SerialPort } from 'serialport';
import { createServer } from 'node:net';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// 读取配置
const CONFIG_PATH = join(__dirname, 'config.json');
let config = { serial: { port: 'COM3', baudRate: 115200 }, tcp: { port: 6001 } };
try {
  config = JSON.parse(readFileSync(CONFIG_PATH, 'utf8'));
} catch {
  console.warn('[Relay] config.json not found, using defaults');
}

const SERIAL_PORT = config.serial.port;
const BAUD_RATE = config.serial.baudRate;
const TCP_PORT = config.tcp.port;

// ============ 状态 ============

let serialPort = null;
let currentSerialPath = SERIAL_PORT;
let tcpClient = null;
let tcpServer = null;       // TCP server 引用，用于重启
let serialBuffer = '';
let pingTimer = null;
const PING_TIMEOUT = 30000;

// ============ 日志 ============

function log(msg) {
  const ts = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  console.log(`[${ts}] ${msg}`);
}

// ============ 串口侧 ============

function openSerial(portPath) {
  if (portPath) {
    currentSerialPath = portPath;
  }
  log(`[Serial] Opening ${currentSerialPath} @ ${BAUD_RATE}...`);

  // 防止重复打开
  if (serialPort) {
    serialPort.removeAllListeners();
    if (serialPort.isOpen) {
      serialPort.close(() => {
        serialPort = null;
        doOpenSerial();
      });
      return;
    }
    serialPort = null;
  }
  doOpenSerial();
}

function doOpenSerial() {
  const port = new SerialPort({
    path: currentSerialPath,
    baudRate: BAUD_RATE,
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    autoOpen: false
  });

  serialPort = port;

  port.on('data', (data) => {
    serialBuffer += data.toString();
    const lines = serialBuffer.split('\r\n');
    serialBuffer = lines.pop();
    for (const line of lines) {
      if (line.length > 0) handleSerialLine(line);
    }
  });

  port.on('error', (err) => {
    log(`[Serial] Error: ${err.message}`);
  });

  port.on('close', () => {
    log('[Serial] Port closed');
    if (serialPort === port) serialPort = null;
    sendToPC('$STATUS,DISCONNECTED\r\n');
    setTimeout(openSerial, 3000);
  });

  port.open((err) => {
    if (err) {
      log(`[Serial] Open error: ${err.message}`);
      setTimeout(openSerial, 3000);
      return;
    }
    log(`[Serial] Opened: ${currentSerialPath}`);
    sendToPC('$STATUS,CONNECTED\r\n');
  });
}

function handleSerialLine(line) {
  log(`[Serial RX] ${line}`);
  // 透传所有 MCU 数据给 PC（协议无关）
  sendToPC(line + '\r\n');
}

function sendToMCU(data) {
  if (serialPort?.isOpen) {
    serialPort.write(data, (err) => {
      if (err) {
        log(`[Serial TX] Error: ${err.message}`);
      } else {
        log(`[Serial TX] ${data.trim()}`);
      }
    });
  } else {
    log('[Serial TX] Port not open, dropped');
  }
}

// ============ 串口管理命令 ============

async function handleListPorts() {
  try {
    const ports = await SerialPort.list();
    const portPaths = ports.map(p => p.path);
    const resp = `$PORTS,${portPaths.join(',')}\r\n`;
    log(`[CMD] LIST_PORTS -> ${portPaths.length} ports: ${portPaths.join(', ')}`);
    sendToPC(resp);
  } catch (err) {
    log(`[CMD] LIST_PORTS error: ${err.message}`);
    sendToPC('$PORTS,\r\n');
  }
}

function handleOpenPort(portPath) {
  if (!portPath || portPath.trim() === '') {
    sendToPC('$CMD_ERR,OPEN,invalid port path\r\n');
    return;
  }

  portPath = portPath.trim();

  if (serialPort?.isOpen && currentSerialPath === portPath) {
    sendToPC('$CMD_OK,OPEN\r\n');
    return;
  }

  // 关闭旧串口事件，避免触发重连
  if (serialPort) {
    serialPort.removeAllListeners();
    if (serialPort.isOpen) {
      serialPort.close(() => {
        serialPort = null;
        openSerial(portPath);
      });
    } else {
      serialPort = null;
      openSerial(portPath);
    }
  } else {
    openSerial(portPath);
  }

  const checkTimer = setInterval(() => {
    if (serialPort?.isOpen && currentSerialPath === portPath) {
      clearInterval(checkTimer);
      sendToPC('$CMD_OK,OPEN\r\n');
    }
  }, 100);
  setTimeout(() => clearInterval(checkTimer), 2000);
}

// ============ TCP 侧 ============

function cleanupTcpClient(reason) {
  if (tcpClient) {
    log(`[TCP] Cleaning up PC connection: ${reason}`);
    tcpClient.removeAllListeners();
    tcpClient.destroy();
    tcpClient = null;
  }
  clearPingTimer();
}

function startTCPServer() {
  // 关闭旧 server（如果有）
  if (tcpServer) {
    try { tcpServer.close(); } catch {}
    tcpServer = null;
  }

  const server = createServer({ allowHalfOpen: false }, (socket) => {
    // 单客户端：新连接替换旧连接
    cleanupTcpClient('new connection incoming');

    tcpClient = socket;
    socket.setKeepAlive(true, 10000);
    socket.setNoDelay(true);

    const addr = `${socket.remoteAddress}:${socket.remotePort}`;
    log(`[TCP] PC connected: ${addr}`);
    resetPingTimer();

    socket.on('data', (data) => {
      const lines = data.toString().split('\r\n');
      for (const line of lines) {
        if (line.length > 0) handleTCPLine(line);
      }
    });

    socket.on('error', (err) => {
      log(`[TCP] PC socket error: ${err.message}`);
      cleanupTcpClient('socket error');
    });

    socket.on('close', () => {
      log('[TCP] PC disconnected');
      cleanupTcpClient('socket close');
    });

    socket.on('end', () => {
      log('[TCP] PC sent FIN');
      // socket 还可以发数据，但标记为半关闭
    });
  });

  server.on('error', (err) => {
    log(`[TCP] Server error: ${err.message}`);
    if (err.code === 'EADDRINUSE') {
      log('[TCP] Port in use, retrying in 3s...');
    }
    setTimeout(startTCPServer, 3000);
  });

  server.listen(TCP_PORT, () => {
    log(`[TCP] Server listening on port ${TCP_PORT}`);
  });

  tcpServer = server;
}

function handleTCPLine(line) {
  log(`[TCP RX] ${line}`);

  if (line === '$PING') {
    sendToPC('$PONG\r\n');
    resetPingTimer();
    return;
  }

  if (line.startsWith('$CMD,')) {
    const cmd = line.substring(5);
    resetPingTimer();
    if (cmd === 'LIST_PORTS') {
      handleListPorts();
    } else if (cmd.startsWith('OPEN,')) {
      handleOpenPort(cmd.substring(5));
    }
    return;
  }

  // 非控制命令的 $ 帧，全部透传给 MCU（协议无关）
  if (line.startsWith('$') && !line.startsWith('$CMD,')) {
    sendToMCU(line + '\r\n');
    resetPingTimer();
  }
}

function sendToPC(data) {
  if (tcpClient && !tcpClient.destroyed && tcpClient.writable) {
    tcpClient.write(data, (err) => {
      if (err) log(`[TCP TX] Error: ${err.message}`);
    });
  }
}

// ============ 心跳检测 ============

function resetPingTimer() {
  clearPingTimer();
  pingTimer = setTimeout(() => {
    log('[TCP] Ping timeout, disconnecting PC');
    cleanupTcpClient('ping timeout');
  }, PING_TIMEOUT);
}

function clearPingTimer() {
  if (pingTimer) {
    clearTimeout(pingTimer);
    pingTimer = null;
  }
}

// ============ 启动 ============

log(`[Relay] Config: serial=${SERIAL_PORT} @ ${BAUD_RATE}, tcp=${TCP_PORT}`);
openSerial();
startTCPServer();
